"""Frozen RuleShift-Web v2 package."""
